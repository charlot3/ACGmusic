CREATE PROCEDURE lab3.randomize()
  begin
  declare i BIGINT;
  declare a1 int;
  DECLARE a2 VARCHAR(255);
  DECLARE a3 varchar(255);
    set i = 1;
      while i <= 1000000 do
          set a1 = floor(rand()*100000000);
       -- while exists(select stuID from stu where a1 = stuID) DO
         -- set a1 = floor(rand()*100000000);
        -- end while;
          set a2 = rand_string(10);
          set a3 = (mod (floor(rand() * 100), 17)+2000) * 10000 + (mod (ceil(rand() * 100), 12)) * 100 + (mod (ceil(rand() * 100), 31)) ;
          insert into stu VALUES (a1, a1, a2, a3);
        set i = i + 1;

      end while;
end;
